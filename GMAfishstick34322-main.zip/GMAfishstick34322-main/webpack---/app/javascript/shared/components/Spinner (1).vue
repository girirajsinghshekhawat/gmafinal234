var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('span',{staticClass:"spinner",class:_vm.size})}
var staticRenderFns = []

export { render, staticRenderFns }