var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('svg',{attrs:{"width":_vm.size,"height":_vm.size,"fill":"none","viewBox":"0 0 24 24","xmlns":"http://www.w3.org/2000/svg"}},_vm._l((_vm.pathSource),function(source){return _c('path',{key:source,attrs:{"d":source,"fill":"currentColor"}})}),0)}
var staticRenderFns = []

export { render, staticRenderFns }