var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('unread-message-list',{attrs:{"messages":_vm.messages}})}
var staticRenderFns = []

export { render, staticRenderFns }