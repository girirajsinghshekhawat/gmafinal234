var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"flex flex-1 flex-col justify-end"},[_c('div',{staticClass:"flex flex-1 overflow-auto"}),_vm._v(" "),_c('team-availability',{attrs:{"available-agents":_vm.availableAgents,"has-conversation":!!_vm.conversationSize},on:{"start-conversation":_vm.startConversation}})],1)}
var staticRenderFns = []

export { render, staticRenderFns }