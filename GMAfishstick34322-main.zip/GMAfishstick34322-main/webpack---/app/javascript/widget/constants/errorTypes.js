export const SET_USER_ERROR = "SET_USER_ERROR";
