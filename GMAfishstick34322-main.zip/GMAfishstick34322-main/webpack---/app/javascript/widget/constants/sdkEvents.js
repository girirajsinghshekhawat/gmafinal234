export const CHATWOOT_ERROR = "chatwoot:error";
export const CHATWOOT_READY = "chatwoot:ready";
