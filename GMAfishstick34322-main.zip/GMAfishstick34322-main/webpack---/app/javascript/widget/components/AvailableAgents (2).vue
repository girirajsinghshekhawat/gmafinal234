var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('grouped-avatars',{attrs:{"users":_vm.users}})}
var staticRenderFns = []

export { render, staticRenderFns }