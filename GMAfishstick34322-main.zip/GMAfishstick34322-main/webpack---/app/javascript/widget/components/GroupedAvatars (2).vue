var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"flex"},_vm._l((_vm.users),function(user,index){return _c('span',{key:user.id,class:((index ? '-ml-4' : '') + " inline-block rounded-full text-white shadow-solid")},[_c('thumbnail',{attrs:{"size":"40px","username":user.name,"src":user.avatar,"has-border":""}})],1)}),0)}
var staticRenderFns = []

export { render, staticRenderFns }