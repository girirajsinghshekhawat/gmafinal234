var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return (_vm.showBannerMessage)?_c('div',{class:("banner " + _vm.bannerType)},[_c('span',[_vm._v("\n    "+_vm._s(_vm.bannerMessage)+"\n  ")])]):_vm._e()}
var staticRenderFns = []

export { render, staticRenderFns }